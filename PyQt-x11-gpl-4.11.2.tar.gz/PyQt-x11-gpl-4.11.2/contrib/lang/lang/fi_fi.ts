<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>Title</source>
        <translation type="unfinished">Otsikko</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Teksti</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished">Kieli</translation>
    </message>
</context>
</TS>
